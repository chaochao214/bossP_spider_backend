from django.apps import AppConfig


class BosspConfig(AppConfig):
    name = 'bossP'
